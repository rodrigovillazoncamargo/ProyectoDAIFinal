package com.example.afranzonv.jarfush;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Crear extends AppCompatActivity {
    private String idUsuario;
    private EditText idPedido, platillo, direccion, cantidad;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crear);
        idPedido = (EditText) findViewById(R.id.etIdPedido);
        platillo = (EditText) findViewById(R.id.etPlatillo);
        direccion = (EditText) findViewById(R.id.etDireccion);
        cantidad = (EditText) findViewById(R.id.etCantidad);
        //Recuperamos el idUsuario
        Bundle bundle = this.getIntent().getExtras();
        idUsuario = bundle.get("idUsuario").toString();

    }

    private void limpiar(View v) {
        idPedido.setText("");
        platillo.setText("");
        direccion.setText("");
        cantidad.setText("");
    }

    //Mandamos a crear pedido
    public void pedido(View v) {
        String id, plat, direc, cant;
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "papprika",null,1);
        SQLiteDatabase bd = admin.getWritableDatabase();
        id = idPedido.getText().toString();
        plat = platillo.getText().toString();
        direc = direccion.getText().toString();
        cant = cantidad.getText().toString();
        ContentValues registro = new ContentValues();
        registro.put("idPedido", id);
        registro.put("platillo",plat);
        registro.put("direccion",direc);
        registro.put("cantidad",cant);
        registro.put("idUsuario", idUsuario);
        bd.insert("Pedido",null,registro);
        bd.close();
        limpiar(v);
        Toast.makeText(this, "se cargaron los datos del pedido",Toast.LENGTH_LONG).show();

    }

    public void regresar(View v) {
        Intent intent = new Intent(Crear.this, Inicio.class);
        Bundle bundle = new Bundle();
        bundle.putString("idUsuario", idUsuario);
        intent.putExtras(bundle);
        startActivity(intent);
    }
}
