package com.example.afranzonv.jarfush;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;

public class Aprender extends AppCompatActivity {
    private String idUsuario;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aprender);
        //Recuperamos el idUsuario
        Bundle bundle = this.getIntent().getExtras();
        idUsuario = bundle.get("idUsuario").toString();
        //ponemos la página
        String url = "http://cocinaconarte.net/recetas-principiantes-48-recetas-faciles-aprender-cocinar/";
        WebView web = (WebView) this.findViewById(R.id.webView);
        web.getSettings().setJavaScriptEnabled(true);
        web.loadUrl(url);
    }

    public void regresar(View v) {
        Intent intent = new Intent(Aprender.this, Inicio.class);
        Bundle bundle = new Bundle();
        bundle.putString("idUsuario", idUsuario);
        intent.putExtras(bundle);
        startActivity(intent);
    }
}
