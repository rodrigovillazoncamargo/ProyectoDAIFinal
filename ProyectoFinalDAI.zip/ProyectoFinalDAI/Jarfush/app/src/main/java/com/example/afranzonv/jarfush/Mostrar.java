package com.example.afranzonv.jarfush;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class Mostrar extends AppCompatActivity {
    private String idUsuario;
    private GridView pedido;
    private Button mostrar, regresar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mostrar);
        pedido = (GridView)findViewById(R.id.gvPedidos);
        //Recuperamos el idUsuario
        Bundle bundle = this.getIntent().getExtras();
        mostrar = (Button)findViewById(R.id.btMostrar);
        idUsuario = bundle.get("idUsuario").toString();

    }
    public void regresar(View v) {
        Intent intent = new Intent(Mostrar.this, Inicio.class);
        Bundle bundle = new Bundle();
        bundle.putString("idUsuario", idUsuario);
        intent.putExtras(bundle);
        startActivity(intent);
    }

    //Genera reporte de todos los pedidos del usuarios
    public void lataMostrar(View v) {
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "papprika", null, 1);
        SQLiteDatabase db = admin.getWritableDatabase();
        List<String> lista = new ArrayList<>();
        Cursor fila = db.rawQuery("select idPedido from Pedido where idUsuario='"+idUsuario+"'", null);
        int i = -1;
        if(fila!=null) {
            Toast.makeText(this, "la", Toast.LENGTH_LONG).show();
            if (fila.moveToFirst()) {
                do{
                  String aux = fila.getString(fila.getColumnIndex("idPedido"));
                    lista.add(aux);
                    i =1;
                  Toast.makeText(this, "Mostrando pedidos", Toast.LENGTH_LONG).show();

                } while(fila.moveToNext());

                ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, lista);
                pedido.setAdapter(adapter);
                if (i == -1)
                    Toast.makeText(this, "ningún pedido encontrado", Toast.LENGTH_SHORT).show();
            }
        }
        db.close();
    }



}
