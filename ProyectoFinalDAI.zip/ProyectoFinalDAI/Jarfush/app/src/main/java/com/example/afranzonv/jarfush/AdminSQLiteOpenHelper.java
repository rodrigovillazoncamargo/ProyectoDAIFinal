package com.example.afranzonv.jarfush;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;



public class AdminSQLiteOpenHelper extends SQLiteOpenHelper{
    public AdminSQLiteOpenHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override

    //Creas script para crear la base de datos
    public void onCreate(SQLiteDatabase db){
        db.execSQL("create table Usuario (idUsuario text primary key, nombre text, correo text, contrasena text, telefono text)");
        db.execSQL("create table Pedido (idPedido text primary key, platillo text, direccion text, cantidad text, idUsuario text references Usuario)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("drop table if exists Pedido");
        db.execSQL("drop table if exists Usuario");
        db.execSQL("create table Usuario (idUsuario text primary key, nombre text, correo text, contrasena text, telefono text)");
        db.execSQL("create table Pedido (idPedido text primary key, platillo text, direccion text, cantidad integer, idUsuario text references Usuario)");
    }

}
