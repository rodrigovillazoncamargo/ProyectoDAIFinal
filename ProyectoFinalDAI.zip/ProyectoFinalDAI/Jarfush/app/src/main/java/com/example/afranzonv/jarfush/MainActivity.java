package com.example.afranzonv.jarfush;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText correo, contraseña;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        correo = (EditText) findViewById(R.id.etCorreo);
        contraseña = (EditText) findViewById(R.id.etContraseña);
    }

    //Sirve para entrar al menu incial del usuario
    public void iniciar(View v) {
        String corr, contra;
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "papprika", null, 1);
        SQLiteDatabase db = admin.getWritableDatabase();
        corr = correo.getText().toString();
        contra = contraseña.getText().toString();
        //Mandamos el query
        Cursor fila = db.rawQuery("select contrasena, idUsuario from Usuario where correo='"+corr+"'", null);
        //si se leyeron datos entramos a revisar que son correctos
        if (fila.moveToFirst()) {
            String contraObtenida = fila.getString(0);
            String idUsuario = fila.getString(1);
            if (contra.equals(contraObtenida)) {
                Toast.makeText(this, "entró", Toast.LENGTH_LONG).show();
                Intent intent = new Intent (MainActivity.this, Inicio.class);
                Bundle b = new Bundle();
                b.putString("idUsuario", idUsuario);
                intent.putExtras(b);
                startActivity(intent);
                Toast.makeText(this, "datos correctos", Toast.LENGTH_SHORT).show();
            }
        }
        else {
            Toast.makeText(this, "el correo es incorrecto", Toast.LENGTH_SHORT).show();
        }
        db.close();
    }




    public void registrar(View v) {
        Intent intent = new Intent(MainActivity.this, Registro.class);
        startActivity(intent);
    }
}
