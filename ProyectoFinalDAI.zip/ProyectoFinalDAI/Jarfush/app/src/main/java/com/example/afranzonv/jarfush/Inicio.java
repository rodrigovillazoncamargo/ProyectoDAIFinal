package com.example.afranzonv.jarfush;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Inicio extends AppCompatActivity {
    private String idUsuario;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio);
        //Recuperamos el idUsuario
        Bundle bundle = this.getIntent().getExtras();
        idUsuario = bundle.get("idUsuario").toString();

    }
    public void crear(View v) {
        Intent intent = new Intent(Inicio.this, Crear.class);
        Bundle bundle = new Bundle();
        bundle.putString("idUsuario", idUsuario);
        intent.putExtras(bundle);
        startActivity(intent);
    }

    public void mostrar(View v) {
        Intent intent = new Intent(Inicio.this, Mostrar.class);
        Bundle bundle = new Bundle();
        bundle.putString("idUsuario", idUsuario);
        intent.putExtras(bundle);
        startActivity(intent);
    }

    public void aprender(View v) {
        Intent intent = new Intent(Inicio.this, Aprender.class);
        Bundle bundle = new Bundle();
        bundle.putString("idUsuario", idUsuario);
        intent.putExtras(bundle);
        startActivity(intent);
    }

    public void salir(View v) {
        Intent intent = new Intent(Inicio.this, MainActivity.class);
        startActivity(intent);
    }
}
