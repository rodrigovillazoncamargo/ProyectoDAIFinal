package com.example.afranzonv.jarfush;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Registro extends AppCompatActivity {
    private EditText idUsuario, nombre, correo, contraseña, telefono;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);
        idUsuario = (EditText) findViewById(R.id.etIdUsuario);
        nombre = (EditText) findViewById(R.id.etNombre);
        correo = (EditText) findViewById(R.id.etCorreo);
        contraseña = (EditText) findViewById(R.id.etContraseña);
        telefono = (EditText) findViewById(R.id.etTelefono);

    }
    private void limpiar(View v) {
        idUsuario.setText("");
        nombre.setText("");
        correo.setText("");
        contraseña.setText("");
        telefono.setText("");
    }

    //Registro del usuario en la base de datos
    public void registrar(View v) {
        String id, nom, corr, contra, tel;
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "papprika",null,1);
        SQLiteDatabase bd = admin.getWritableDatabase();
        id = idUsuario.getText().toString();
        nom = nombre.getText().toString();
        corr = correo.getText().toString();
        contra = contraseña.getText().toString();
        tel = telefono.getText().toString();
        ContentValues registro = new ContentValues();
        registro.put("idUsuario", id);
        registro.put("nombre",nom);
        registro.put("correo",corr);
        registro.put("contrasena",contra);
        registro.put("telefono", tel);
        long i = bd.insert("Usuario",null,registro);
        if(i > 0)
            Toast.makeText(this, "se cargaron los datos de la persona", Toast.LENGTH_LONG).show();
        else
            Toast.makeText(this, "no se cargaron los datos de la persona", Toast.LENGTH_LONG).show();
        bd.close();
        limpiar(v);
    }

    public void regresar(View v) {
        Intent intent = new Intent(Registro.this, MainActivity.class);
        startActivity(intent);
    }
}
